package cn.java666.szthbase;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SztHbaseApp {

    public static void main(String[] args) {
        SpringApplication.run(SztHbaseApp.class, args);
    }
}
